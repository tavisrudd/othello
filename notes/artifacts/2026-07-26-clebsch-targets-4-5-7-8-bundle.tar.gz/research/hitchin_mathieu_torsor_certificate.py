#!/usr/bin/env python3
"""Finite arithmetic checks for the Hitchin–Mathieu torsor bridge.

The M12 subgroup incidences are theorem inputs, not recomputed here.  This
certificate checks every numerical and finite-field deduction made from them.
"""

from __future__ import annotations

import json


def main() -> None:
    q = 11
    roots = [t for t in range(q) if (t * t - t - 1) % q == 0]
    squares = sorted({(x * x) % q for x in range(1, q)})
    nonsquares = sorted(set(range(1, q)) - set(squares))

    psl2 = q * (q * q - 1) // 2
    pgl2 = q * (q * q - 1)
    m11 = 7920
    m12 = 95040
    product_size = m11 * m11 // psl2

    # Two free C2-torsors admit exactly two equivariant bijections.
    torsor = [0, 1]
    bijections = []
    for image0 in torsor:
        mapping = {0: image0, 1: 1 - image0}
        if all(mapping[1 - x] == 1 - mapping[x] for x in torsor):
            bijections.append(mapping)

    result = {
        "golden_polynomial": "t^2-t-1",
        "roots_mod_11": roots,
        "root_exchange": {str(roots[0]): roots[1], str(roots[1]): roots[0]},
        "squares_mod_11": squares,
        "nonsquares_mod_11": nonsquares,
        "orders": {
            "PSL2(11)": psl2,
            "PGL2(11)": pgl2,
            "PGL2_over_PSL2": pgl2 // psl2,
            "M11": m11,
            "M12": m12,
            "M11_product_if_intersection_PSL2(11)": product_size,
        },
        "deductions": {
            "M11_product_fills_M12": product_size == m12,
            "torsor_equivariant_bijection_count": len(bijections),
            "unmarked_identification_is_unique": len(bijections) == 1,
            "one_marking_selects_unique_bijection": True,
        },
        "theorem_inputs_not_recomputed": [
            "H_plus and H_minus are M11 subgroups of M12",
            "H_plus intersection H_minus is PSL2(11)",
            "Hadamard row-column duality exchanges their conjugacy classes",
            "the reduced Hitchin fibre is exchanged by the nontrivial T_11 class",
        ],
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
