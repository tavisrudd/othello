#!/usr/bin/env python3
"""Exact compiler for complete bounded repair ports over a prime field.

Input is a JSON object containing a generator matrix, a prime q, and a radius.
For each requested target, the compiler enumerates every normalized dual word
whose helper support has size at most the radius.  It retains coefficient
fibres, extracts the minimal support clutter, computes matching/transversal
numbers, the homogeneous reliability polynomial, heterogeneous reliability,
and an optimal adaptive policy for querying helper availability.

This is intentionally an exact finite-instance compiler.  Exponential steps
are explicit in the certificate and are appropriate for bounded inner seeds.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from functools import lru_cache
from pathlib import Path
from typing import Iterable, Sequence


def inv_mod(a: int, p: int) -> int:
    return pow(a % p, -1, p)


def rref(matrix: Sequence[Sequence[int]], p: int) -> tuple[list[list[int]], list[int]]:
    a = [[x % p for x in row] for row in matrix]
    if not a:
        return [], []
    rows, cols = len(a), len(a[0])
    pivots: list[int] = []
    r = 0
    for c in range(cols):
        pivot = next((i for i in range(r, rows) if a[i][c] % p), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        scale = inv_mod(a[r][c], p)
        a[r] = [(scale * x) % p for x in a[r]]
        for i in range(rows):
            if i != r and a[i][c] % p:
                factor = a[i][c]
                a[i] = [(x - factor * y) % p for x, y in zip(a[i], a[r])]
        pivots.append(c)
        r += 1
        if r == rows:
            break
    nonzero = [row for row in a if any(x % p for x in row)]
    return nonzero, pivots


def solve_affine(
    a: Sequence[Sequence[int]], b: Sequence[int], p: int
) -> tuple[list[int], list[list[int]]] | None:
    """Return one solution and a nullspace basis for A x = b."""
    rows = len(a)
    cols = len(a[0]) if rows else 0
    aug = [
        [*(a[i][j] % p for j in range(cols)), b[i] % p]
        for i in range(rows)
    ]
    rr, _ = rref(aug, p)
    for row in rr:
        if not any(row[j] % p for j in range(cols)) and row[cols] % p:
            return None
    pivot_rows: dict[int, list[int]] = {}
    for row in rr:
        pivot = next((j for j in range(cols) if row[j] % p), None)
        if pivot is not None:
            pivot_rows[pivot] = row
    free = [j for j in range(cols) if j not in pivot_rows]
    particular = [0] * cols
    for pivot, row in pivot_rows.items():
        particular[pivot] = row[cols] % p
    basis: list[list[int]] = []
    for free_col in free:
        v = [0] * cols
        v[free_col] = 1
        for pivot, row in pivot_rows.items():
            v[pivot] = (-row[free_col]) % p
        basis.append(v)
    return particular, basis


def nullspace(a: Sequence[Sequence[int]], p: int) -> list[list[int]]:
    cols = len(a[0]) if a else 0
    solved = solve_affine(a, [0] * len(a), p)
    if solved is None:
        raise AssertionError("homogeneous system is inconsistent")
    _, basis = solved
    if cols == 0:
        return []
    return basis


def canonical_rowspace(a: Sequence[Sequence[int]], p: int) -> list[list[int]]:
    rr, _ = rref(a, p)
    return rr


def enumerate_affine(
    particular: Sequence[int],
    basis: Sequence[Sequence[int]],
    p: int,
    max_solutions: int,
) -> Iterable[list[int]]:
    total = p ** len(basis)
    if total > max_solutions:
        raise RuntimeError(
            f"coefficient fibre has {total} solutions; max_solutions={max_solutions}"
        )
    for scalars in itertools.product(range(p), repeat=len(basis)):
        yield [
            (
                particular[j]
                + sum(s * basis[i][j] for i, s in enumerate(scalars))
            )
            % p
            for j in range(len(particular))
        ]


def enumerate_repairs(
    generator: Sequence[Sequence[int]],
    p: int,
    target: int,
    radius: int,
    max_solutions: int,
) -> list[dict]:
    k = len(generator)
    n = len(generator[0])
    helpers = [j for j in range(n) if j != target]
    repairs: list[dict] = []
    target_col = [generator[i][target] % p for i in range(k)]
    for size in range(1, min(radius, len(helpers)) + 1):
        for support in itertools.combinations(helpers, size):
            a = [[generator[i][j] % p for j in support] for i in range(k)]
            solved = solve_affine(a, [(-x) % p for x in target_col], p)
            if solved is None:
                continue
            particular, basis = solved
            coefficients = set()
            for dual_coeffs in enumerate_affine(particular, basis, p, max_solutions):
                if all(x % p for x in dual_coeffs):
                    # h_target=1 and G h^T=0, hence c_target =
                    # sum_j (-h_j)c_j.
                    recovery = tuple((-x) % p for x in dual_coeffs)
                    coefficients.add(recovery)
            if coefficients:
                repairs.append(
                    {
                        "support": list(support),
                        "coefficient_fibre": [list(c) for c in sorted(coefficients)],
                    }
                )
    return repairs


def minimal_repairs(repairs: Sequence[dict]) -> list[dict]:
    supports = [frozenset(r["support"]) for r in repairs]
    out = []
    for i, repair in enumerate(repairs):
        s = supports[i]
        if not any(t < s for t in supports):
            out.append(repair)
    return out


def matching_number(edges: Sequence[frozenset[int]]) -> tuple[int, list[list[int]]]:
    ordered = sorted(edges, key=lambda e: (len(e), tuple(sorted(e))))
    best: list[frozenset[int]] = []

    def search(i: int, used: frozenset[int], chosen: list[frozenset[int]]) -> None:
        nonlocal best
        if len(chosen) + len(ordered) - i <= len(best):
            return
        if i == len(ordered):
            if len(chosen) > len(best):
                best = chosen[:]
            return
        search(i + 1, used, chosen)
        if not ordered[i] & used:
            chosen.append(ordered[i])
            search(i + 1, used | ordered[i], chosen)
            chosen.pop()

    search(0, frozenset(), [])
    return len(best), [sorted(e) for e in best]


def transversal_number(
    edges: Sequence[frozenset[int]], vertices: Sequence[int]
) -> tuple[int, list[int]]:
    if not edges:
        return 0, []
    for size in range(len(vertices) + 1):
        for subset in itertools.combinations(vertices, size):
            chosen = frozenset(subset)
            if all(chosen & edge for edge in edges):
                return size, list(subset)
    raise AssertionError("finite hypergraph has no transversal")


def homogeneous_reliability(
    edges: Sequence[frozenset[int]], vertices: Sequence[int]
) -> dict:
    success_counts = [0] * (len(vertices) + 1)
    failure_counts = [0] * (len(vertices) + 1)
    for bits in range(1 << len(vertices)):
        alive = frozenset(
            vertices[i] for i in range(len(vertices)) if bits & (1 << i)
        )
        success = any(edge <= alive for edge in edges)
        (success_counts if success else failure_counts)[len(alive)] += 1
    return {
        "basis": "sum_k count[k] * s^k * (1-s)^(m-k)",
        "success_counts": success_counts,
        "failure_counts": failure_counts,
    }


def heterogeneous_success_probability(
    edges: Sequence[frozenset[int]],
    vertices: Sequence[int],
    survival: dict[int, float],
) -> float:
    total = 0.0
    for bits in range(1 << len(vertices)):
        alive = frozenset(
            vertices[i] for i in range(len(vertices)) if bits & (1 << i)
        )
        probability = 1.0
        for i, vertex in enumerate(vertices):
            probability *= (
                survival[vertex] if bits & (1 << i) else 1.0 - survival[vertex]
            )
        if any(edge <= alive for edge in edges):
            total += probability
    return total


def optimal_adaptive_policy(
    edges: Sequence[frozenset[int]],
    vertices: Sequence[int],
    survival: dict[int, float],
    query_cost: dict[int, float],
) -> dict:
    """Minimize expected query cost until success or certified impossibility."""
    vertex_index = {v: i for i, v in enumerate(vertices)}
    indexed_edges = [
        sum(1 << vertex_index[v] for v in edge)
        for edge in edges
    ]
    full = (1 << len(vertices)) - 1
    choices: dict[tuple[int, int], int] = {}

    @lru_cache(maxsize=None)
    def value(alive: int, dead: int) -> float:
        if any(edge & alive == edge for edge in indexed_edges):
            return 0.0
        if not any(edge & dead == 0 for edge in indexed_edges):
            return 0.0
        unknown = full & ~(alive | dead)
        best = math.inf
        best_j = -1
        for i, vertex in enumerate(vertices):
            bit = 1 << i
            if unknown & bit:
                s = survival[vertex]
                candidate = (
                    query_cost[vertex]
                    + s * value(alive | bit, dead)
                    + (1.0 - s) * value(alive, dead | bit)
                )
                if candidate < best - 1e-14:
                    best, best_j = candidate, vertex
        if best_j < 0:
            return 0.0
        choices[(alive, dead)] = best_j
        return best

    expected = value(0, 0)
    root = choices.get((0, 0))
    policy_rows = [
        {
            "alive_mask": alive,
            "dead_mask": dead,
            "query_helper": helper,
        }
        for (alive, dead), helper in sorted(choices.items())
    ]
    return {
        "objective": "expected helper-availability query cost until repair or impossibility is certified",
        "expected_cost": expected,
        "first_query": root,
        "decision_states": len(policy_rows),
        "policy": policy_rows,
    }


def reconstruction_from_port(
    repairs: Sequence[dict], n: int, target: int, p: int
) -> dict:
    dual_rows = []
    for repair in repairs:
        support = repair["support"]
        for recovery in repair["coefficient_fibre"]:
            h = [0] * n
            h[target] = 1
            for j, coefficient in zip(support, recovery):
                h[j] = (-coefficient) % p
            dual_rows.append(h)
    dual_span = canonical_rowspace(dual_rows, p)
    if dual_span:
        reconstructed = canonical_rowspace(nullspace(dual_span, p), p)
    else:
        reconstructed = [[1 if i == j else 0 for j in range(n)] for i in range(n)]
    return {
        "normalized_dual_word_count": len(dual_rows),
        "dual_span_rank": len(dual_span),
        "dual_span_basis": dual_span,
        "reconstructed_generator_rref": reconstructed,
    }


def verify_repairs(
    generator: Sequence[Sequence[int]], p: int, target: int, repairs: Sequence[dict]
) -> bool:
    k = len(generator)
    for repair in repairs:
        for recovery in repair["coefficient_fibre"]:
            for row in range(k):
                rhs = sum(
                    recovery[i] * generator[row][j]
                    for i, j in enumerate(repair["support"])
                ) % p
                if rhs != generator[row][target] % p:
                    return False
    return True


def compile_target(config: dict, target: int) -> dict:
    p = int(config["q"])
    generator = config["generator"]
    n = len(generator[0])
    radius = int(config["radius"])
    max_solutions = int(config.get("max_solutions_per_fibre", 1_000_000))
    repairs = enumerate_repairs(generator, p, target, radius, max_solutions)
    minimal = minimal_repairs(repairs)
    vertices = [j for j in range(n) if j != target]
    edges = [frozenset(r["support"]) for r in minimal]
    nu, matching = matching_number(edges)
    tau, transversal = transversal_number(edges, vertices)
    survival_raw = config.get("survival_probabilities", {})
    costs_raw = config.get("helper_query_costs", {})
    survival = {
        v: float(survival_raw.get(str(v), survival_raw.get(v, 0.9))) for v in vertices
    }
    query_cost = {
        v: float(costs_raw.get(str(v), costs_raw.get(v, 1.0))) for v in vertices
    }
    reconstruction = reconstruction_from_port(minimal, n, target, p)
    original = canonical_rowspace(generator, p)
    return {
        "target": target,
        "all_exact_support_repairs": repairs,
        "minimal_repairs": minimal,
        "support_invariants": {
            "matching_number": nu,
            "matching_witness": matching,
            "transversal_number": tau,
            "transversal_witness": transversal,
        },
        "reliability": {
            "homogeneous": homogeneous_reliability(edges, vertices),
            "heterogeneous_success_probability": heterogeneous_success_probability(
                edges, vertices, survival
            ),
            "survival_probabilities": {str(k): v for k, v in survival.items()},
        },
        "adaptive_policy": optimal_adaptive_policy(
            edges, vertices, survival, query_cost
        ),
        "reconstruction": {
            **reconstruction,
            "equals_input_code": (
                reconstruction["reconstructed_generator_rref"] == original
            ),
        },
        "checks": {
            "all_recovery_equations_verified": verify_repairs(
                generator, p, target, repairs
            ),
            "minimal_supports_are_antichain": all(
                not (a < b)
                for i, a in enumerate(edges)
                for j, b in enumerate(edges)
                if i != j
            ),
        },
    }


def compile_port(config: dict) -> dict:
    p = int(config["q"])
    generator = config["generator"]
    if p < 2 or any(p % d == 0 for d in range(2, int(math.sqrt(p)) + 1)):
        raise ValueError("this compiler version requires q to be prime")
    if not generator or not generator[0]:
        raise ValueError("generator must be a nonempty rectangular matrix")
    n = len(generator[0])
    if any(len(row) != n for row in generator):
        raise ValueError("generator matrix is not rectangular")
    targets = config.get("targets", list(range(n)))
    result = {
        "schema": "complete-repair-port-certificate-v1",
        "field": f"GF({p})",
        "length": n,
        "dimension": len(canonical_rowspace(generator, p)),
        "radius": int(config["radius"]),
        "generator_rref": canonical_rowspace(generator, p),
        "targets": [compile_target(config, int(t)) for t in targets],
        "complexity_note": (
            "Exact bounded-seed compilation enumerates helper subsets, affine "
            "coefficient fibres, availability states, and adaptive-policy states."
        ),
    }
    canonical = json.dumps(result, sort_keys=True, separators=(",", ":")).encode()
    result["sha256_without_digest"] = hashlib.sha256(canonical).hexdigest()
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("-o", "--output", type=Path)
    args = parser.parse_args()
    config = json.loads(args.input.read_text())
    result = compile_port(config)
    payload = json.dumps(result, indent=2, sort_keys=True) + "\n"
    if args.output:
        args.output.write_text(payload)
    else:
        print(payload, end="")


if __name__ == "__main__":
    main()
