#!/usr/bin/env python3

import json
import unittest
from pathlib import Path

from repair_port_compiler import compile_port


ROOT = Path(__file__).resolve().parent


class ClebschPortTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        config = json.loads((ROOT / "clebsch_repair_port.json").read_text())
        cls.result = compile_port(config)
        cls.target = cls.result["targets"][0]

    def test_complete_triple_clutter(self):
        supports = {
            tuple(row["support"]) for row in self.target["minimal_repairs"]
        }
        self.assertEqual(len(supports), 10)
        self.assertEqual({len(s) for s in supports}, {3})
        self.assertEqual(
            supports,
            {
                tuple(s)
                for s in __import__("itertools").combinations([1, 2, 3, 4, 5], 3)
            },
        )

    def test_matching_and_transversal(self):
        inv = self.target["support_invariants"]
        self.assertEqual(inv["matching_number"], 1)
        self.assertEqual(inv["transversal_number"], 3)

    def test_coefficients_verify_and_reconstruct(self):
        self.assertTrue(self.target["checks"]["all_recovery_equations_verified"])
        self.assertTrue(self.target["reconstruction"]["equals_input_code"])
        self.assertEqual(self.target["reconstruction"]["dual_span_rank"], 3)
        for target in self.result["targets"]:
            self.assertEqual(len(target["minimal_repairs"]), 10)
            self.assertTrue(target["reconstruction"]["equals_input_code"])
            self.assertTrue(target["checks"]["all_recovery_equations_verified"])

    def test_reliability_counts(self):
        rel = self.target["reliability"]["homogeneous"]
        self.assertEqual(rel["success_counts"], [0, 0, 0, 10, 5, 1])
        self.assertEqual(rel["failure_counts"], [1, 5, 10, 0, 0, 0])

    def test_policy_is_nontrivial(self):
        policy = self.target["adaptive_policy"]
        self.assertIn(policy["first_query"], [1, 2, 3, 4, 5])
        self.assertGreater(policy["decision_states"], 0)
        self.assertGreater(policy["expected_cost"], 0.0)

    def test_coefficient_fibre_is_retained(self):
        result = compile_port(
            {
                "q": 5,
                "generator": [[1, 1, 1]],
                "radius": 2,
                "targets": [0],
            }
        )
        repairs = result["targets"][0]["all_exact_support_repairs"]
        double = next(r for r in repairs if r["support"] == [1, 2])
        self.assertEqual(
            double["coefficient_fibre"],
            [[2, 4], [3, 3], [4, 2]],
        )

    def test_empty_port_is_handled(self):
        result = compile_port(
            {
                "q": 5,
                "generator": [[1, 0]],
                "radius": 1,
                "targets": [0],
            }
        )
        target = result["targets"][0]
        self.assertEqual(target["minimal_repairs"], [])
        self.assertEqual(target["reconstruction"]["dual_span_rank"], 0)
        self.assertFalse(target["reconstruction"]["equals_input_code"])
        self.assertEqual(
            target["reliability"]["homogeneous"]["success_counts"],
            [0, 0],
        )


if __name__ == "__main__":
    unittest.main()
