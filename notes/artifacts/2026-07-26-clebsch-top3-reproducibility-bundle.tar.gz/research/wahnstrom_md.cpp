#include <algorithm>
#include <array>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <random>
#include <string>
#include <utility>
#include <vector>

struct Vec3 {
    double x = 0;
    double y = 0;
    double z = 0;
};

Vec3 operator+(Vec3 a, Vec3 b) { return {a.x + b.x, a.y + b.y, a.z + b.z}; }
Vec3 operator-(Vec3 a, Vec3 b) { return {a.x - b.x, a.y - b.y, a.z - b.z}; }
Vec3 operator*(double s, Vec3 a) { return {s * a.x, s * a.y, s * a.z}; }
Vec3 operator/(Vec3 a, double s) { return {a.x / s, a.y / s, a.z / s}; }
Vec3& operator+=(Vec3& a, Vec3 b) {
    a.x += b.x;
    a.y += b.y;
    a.z += b.z;
    return a;
}
Vec3& operator-=(Vec3& a, Vec3 b) {
    a.x -= b.x;
    a.y -= b.y;
    a.z -= b.z;
    return a;
}

double norm2(Vec3 a) { return a.x * a.x + a.y * a.y + a.z * a.z; }

double nearest_image(double value, double box) {
    return value - box * std::nearbyint(value / box);
}

Vec3 nearest_image(Vec3 value, double box) {
    return {
        nearest_image(value.x, box),
        nearest_image(value.y, box),
        nearest_image(value.z, box),
    };
}

double sigma_pair(int a, int b) {
    if (a == 0 && b == 0) return 1.0;
    if (a == 1 && b == 1) return 5.0 / 6.0;
    return 11.0 / 12.0;
}

double mass(int type) { return type == 0 ? 2.0 : 1.0; }

struct Simulation {
    int n;
    double density;
    double box;
    double skin = 0.35;
    std::vector<int> type;
    std::vector<Vec3> position;
    std::vector<Vec3> velocity;
    std::vector<Vec3> force;
    std::vector<Vec3> rebuild_position;
    std::vector<std::pair<int, int>> pairs;
    double potential = 0;

    Simulation(int particle_count, double number_density, std::mt19937_64& rng)
        : n(particle_count),
          density(number_density),
          box(std::cbrt(particle_count / number_density)),
          type(particle_count),
          position(particle_count),
          velocity(particle_count),
          force(particle_count),
          rebuild_position(particle_count) {
        initialize_fcc(rng);
        initialize_types(rng);
        initialize_velocities(rng, 1.2);
        rebuild_pairs();
        compute_forces();
    }

    void initialize_fcc(std::mt19937_64& rng) {
        const int cells = 5;
        const double lattice = box / cells;
        const std::array<Vec3, 4> basis = {
            Vec3{0, 0, 0},
            Vec3{0, 0.5, 0.5},
            Vec3{0.5, 0, 0.5},
            Vec3{0.5, 0.5, 0},
        };
        std::normal_distribution<double> jitter(0, 0.015);
        int index = 0;
        for (int ix = 0; ix < cells; ++ix) {
            for (int iy = 0; iy < cells; ++iy) {
                for (int iz = 0; iz < cells; ++iz) {
                    for (const auto& offset : basis) {
                        position[index++] = {
                            lattice * (ix + offset.x) + jitter(rng),
                            lattice * (iy + offset.y) + jitter(rng),
                            lattice * (iz + offset.z) + jitter(rng),
                        };
                    }
                }
            }
        }
    }

    void initialize_types(std::mt19937_64& rng) {
        std::fill(type.begin(), type.begin() + n / 2, 0);
        std::fill(type.begin() + n / 2, type.end(), 1);
        std::shuffle(type.begin(), type.end(), rng);
    }

    void initialize_velocities(std::mt19937_64& rng, double temperature) {
        std::normal_distribution<double> normal(0, 1);
        Vec3 momentum;
        for (int i = 0; i < n; ++i) {
            velocity[i] = {
                normal(rng) / std::sqrt(mass(type[i])),
                normal(rng) / std::sqrt(mass(type[i])),
                normal(rng) / std::sqrt(mass(type[i])),
            };
            momentum += mass(type[i]) * velocity[i];
        }
        for (int i = 0; i < n; ++i) velocity[i] -= momentum / (n * mass(type[i]));
        rescale_temperature(temperature);
    }

    double temperature() const {
        double kinetic = 0;
        for (int i = 0; i < n; ++i) kinetic += 0.5 * mass(type[i]) * norm2(velocity[i]);
        return 2 * kinetic / (3 * n - 3);
    }

    void rescale_temperature(double target) {
        const double scale = std::sqrt(target / temperature());
        for (auto& value : velocity) value = scale * value;
    }

    void rebuild_pairs() {
        pairs.clear();
        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) {
                Vec3 delta = nearest_image(position[i] - position[j], box);
                const double cutoff = 2.5 * sigma_pair(type[i], type[j]) + skin;
                if (norm2(delta) < cutoff * cutoff) pairs.emplace_back(i, j);
            }
        }
        rebuild_position = position;
    }

    bool needs_rebuild() const {
        double maximum = 0;
        for (int i = 0; i < n; ++i) {
            maximum = std::max(maximum, norm2(position[i] - rebuild_position[i]));
        }
        return maximum > 0.25 * skin * skin;
    }

    void compute_forces() {
        std::fill(force.begin(), force.end(), Vec3{});
        potential = 0;
        for (auto [i, j] : pairs) {
            Vec3 delta = nearest_image(position[i] - position[j], box);
            const double r2 = norm2(delta);
            const double sigma = sigma_pair(type[i], type[j]);
            const double cutoff = 2.5 * sigma;
            if (r2 >= cutoff * cutoff) continue;

            const double inverse_r2 = 1.0 / r2;
            const double sr2 = sigma * sigma * inverse_r2;
            const double sr6 = sr2 * sr2 * sr2;
            const double sr12 = sr6 * sr6;
            const double r = std::sqrt(r2);
            const double src2 = 1.0 / 6.25;
            const double src6 = src2 * src2 * src2;
            const double src12 = src6 * src6;
            const double cutoff_force = 24 * (2 * src12 - src6) / cutoff;
            const double coefficient =
                24 * (2 * sr12 - sr6) * inverse_r2 - cutoff_force / r;
            const Vec3 pair_force = coefficient * delta;
            force[i] += pair_force;
            force[j] -= pair_force;

            const double raw = 4 * (sr12 - sr6);
            const double cutoff_energy = 4 * (src12 - src6);
            potential += raw - cutoff_energy + (r - cutoff) * cutoff_force;
        }
    }

    void step(double dt, double target_temperature, double thermostat_time) {
        for (int i = 0; i < n; ++i) {
            velocity[i] += (0.5 * dt / mass(type[i])) * force[i];
            position[i] += dt * velocity[i];
        }
        if (needs_rebuild()) rebuild_pairs();
        compute_forces();
        for (int i = 0; i < n; ++i) {
            velocity[i] += (0.5 * dt / mass(type[i])) * force[i];
        }
        const double factor = std::sqrt(
            std::max(0.0, 1 + dt / thermostat_time * (target_temperature / temperature() - 1))
        );
        for (auto& value : velocity) value = factor * value;
    }
};

double schedule(int step) {
    if (step < 5000) return 1.2;
    if (step < 18000) {
        const double fraction = (step - 5000) / 13000.0;
        return 1.2 + fraction * (0.58 - 1.2);
    }
    return 0.58;
}

int main(int argc, char** argv) {
    const std::string output = argc > 1 ? argv[1] : "wahnstrom_trajectory.csv";
    const int steps = argc > 2 ? std::stoi(argv[2]) : 30000;
    const std::uint64_t seed = argc > 3 ? std::stoull(argv[3]) : 20260725;
    std::mt19937_64 rng(seed);
    Simulation simulation(500, 1.296, rng);
    std::ofstream stream(output);
    stream << "step,id,type,x,y,z,box,temperature,potential_per_atom\n";
    stream << std::setprecision(12);

    const double dt = 0.003;
    for (int step = 0; step <= steps; ++step) {
        if (step >= 20000 && step % 200 == 0) {
            const double temperature = simulation.temperature();
            const double potential = simulation.potential / simulation.n;
            for (int i = 0; i < simulation.n; ++i) {
                const auto& p = simulation.position[i];
                stream << step << ',' << i << ',' << simulation.type[i] << ','
                       << p.x << ',' << p.y << ',' << p.z << ',' << simulation.box << ','
                       << temperature << ',' << potential << '\n';
            }
        }
        if (step == steps) break;
        simulation.step(dt, schedule(step), 0.2);
        if (step % 2500 == 0) {
            std::cerr << step << " T=" << simulation.temperature()
                      << " U/N=" << simulation.potential / simulation.n
                      << " pairs=" << simulation.pairs.size() << '\n';
        }
    }
}
