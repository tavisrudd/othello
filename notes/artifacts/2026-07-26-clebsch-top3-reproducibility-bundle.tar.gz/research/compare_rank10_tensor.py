import argparse
import json
from fractions import Fraction
from pathlib import Path


def rational(value):
    if isinstance(value, int):
        return Fraction(value)
    if isinstance(value, float):
        return Fraction(str(value))
    return Fraction(value)


def pair_embedding():
    pairs = [(i, j) for i in range(5) for j in range(i + 1, 5)]
    matrix = []
    for i, j in pairs:
        row = []
        for coordinate in range(4):
            value = int(i == coordinate) + int(j == coordinate)
            value -= int(i == 4) + int(j == 4)
            row.append(Fraction(value))
        matrix.append(row)
    return pairs, matrix


def clebsch_tensor():
    return [
        [
            [
                Fraction(0) if a == b == c else Fraction(-1, 3)
                for c in range(4)
            ]
            for b in range(4)
        ]
        for a in range(4)
    ]


def restrict_tensor(tensor, embedding):
    restricted = [
        [[Fraction(0) for _ in range(4)] for _ in range(4)]
        for _ in range(4)
    ]
    for a in range(4):
        for b in range(4):
            for c in range(4):
                restricted[a][b][c] = sum(
                    tensor[i][j][k]
                    * embedding[i][a]
                    * embedding[j][b]
                    * embedding[k][c]
                    for i in range(10)
                    for j in range(10)
                    for k in range(10)
                )
    return restricted


def compare(restricted, target):
    scale = None
    for a in range(4):
        for b in range(4):
            for c in range(4):
                if target[a][b][c]:
                    candidate = restricted[a][b][c] / target[a][b][c]
                    if scale is None:
                        scale = candidate
                    elif candidate != scale:
                        return False, None, (a, b, c, restricted[a][b][c], target[a][b][c])
                elif restricted[a][b][c]:
                    return False, None, (a, b, c, restricted[a][b][c], target[a][b][c])
    return scale not in (None, 0), scale, None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("tensor_json", type=Path)
    arguments = parser.parse_args()
    payload = json.loads(arguments.tensor_json.read_text())
    tensor = [
        [[rational(payload["tensor"][i][j][k]) for k in range(10)] for j in range(10)]
        for i in range(10)
    ]
    pairs, embedding = pair_embedding()
    restricted = restrict_tensor(tensor, embedding)
    success, scale, mismatch = compare(restricted, clebsch_tensor())
    result = {
        "pair_order": pairs,
        "nonzero_clebsch_restriction": success,
        "scale": str(scale) if scale is not None else None,
        "mismatch": [str(value) for value in mismatch] if mismatch else None,
    }
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if success else 1)


if __name__ == "__main__":
    main()
