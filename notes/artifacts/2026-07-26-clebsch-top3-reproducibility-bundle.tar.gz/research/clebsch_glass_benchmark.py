import argparse
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial import ConvexHull, cKDTree
from scipy.special import sph_harm_y
from sklearn.ensemble import HistGradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, r2_score, roc_auc_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression


def p6(value):
    value2 = value * value
    return (231 * value2**3 - 315 * value2**2 + 105 * value2 - 5) / 16


def wigner_3j_equal_l(l, m1, m2, m3):
    if m1 + m2 + m3 != 0:
        return 0.0
    triangle = (
        math.factorial(l) ** 3
        / math.factorial(3 * l + 1)
    )
    prefactor = (-1) ** (-m3)
    prefactor *= math.sqrt(
        triangle
        * math.factorial(l + m1)
        * math.factorial(l - m1)
        * math.factorial(l + m2)
        * math.factorial(l - m2)
        * math.factorial(l + m3)
        * math.factorial(l - m3)
    )
    total = 0.0
    lower = max(0, -m1, m2)
    upper = min(l, l - m1, l + m2)
    for z in range(lower, upper + 1):
        denominator = (
            math.factorial(z)
            * math.factorial(l - z)
            * math.factorial(l - m1 - z)
            * math.factorial(l + m2 - z)
            * math.factorial(m1 + z)
            * math.factorial(-m2 + z)
        )
        total += (-1) ** z / denominator
    return prefactor * total


WIGNER6 = {
    (m1, m2, -m1 - m2): wigner_3j_equal_l(6, m1, m2, -m1 - m2)
    for m1 in range(-6, 7)
    for m2 in range(-6, 7)
    if -6 <= -m1 - m2 <= 6
}


def harmonic_coefficients(directions, weights=None):
    directions = np.asarray(directions)
    weights = (
        np.full(len(directions), 1 / len(directions))
        if weights is None
        else np.asarray(weights)
    )
    theta = np.arccos(np.clip(directions[:, 2], -1, 1))
    phi = np.mod(np.arctan2(directions[:, 1], directions[:, 0]), 2 * np.pi)
    return np.array(
        [
            np.sum(weights * sph_harm_y(6, m, theta, phi))
            for m in range(-6, 7)
        ]
    )


def normalized_w6(coefficients):
    norm = np.sum(np.abs(coefficients) ** 2)
    if norm < 1e-20:
        return np.nan
    value = 0j
    for (m1, m2, m3), coefficient in WIGNER6.items():
        value += (
            coefficient
            * coefficients[m1 + 6]
            * coefficients[m2 + 6]
            * coefficients[m3 + 6]
        )
    return float(np.real(value) / norm**1.5)


def q6(directions):
    gram = np.asarray(directions) @ np.asarray(directions).T
    return float(np.sqrt(max(0, np.mean(p6(gram)))))


def pair_opposite_faces(directions):
    faces = ConvexHull(directions).simplices
    if len(faces) != 20:
        return None
    normals = np.array(
        [
            np.mean(directions[face], axis=0)
            / np.linalg.norm(np.mean(directions[face], axis=0))
            for face in faces
        ]
    )
    available = set(range(20))
    pairs = []
    while available:
        i = min(available)
        candidates = np.array(sorted(available - {i}))
        j = int(candidates[np.argmin(normals[candidates] @ normals[i])])
        pairs.append((i, j))
        available.remove(i)
        available.remove(j)

    adjacency = np.zeros((10, 10), dtype=float)
    for a, pair_a in enumerate(pairs):
        for b, pair_b in enumerate(pairs[a + 1 :], start=a + 1):
            adjacent = any(
                len(set(faces[i]) & set(faces[j])) == 2
                for i in pair_a
                for j in pair_b
            )
            adjacency[a, b] = adjacency[b, a] = adjacent
    if not np.all(adjacency.sum(axis=1) == 3):
        return None
    if not np.allclose(np.sort(np.linalg.eigvalsh(adjacency)), [-2] * 4 + [1] * 5 + [3]):
        return None

    axes = []
    for i, j in pairs:
        axis = normals[i] - normals[j]
        axes.append(axis / np.linalg.norm(axis))
    return faces, pairs, np.array(axes), adjacency


def clebsch_channel(directions, radii, species):
    paired = pair_opposite_faces(directions)
    if paired is None:
        return None
    faces, pairs, axes, adjacency = paired
    projection = (adjacency - 3 * np.eye(10)) @ (adjacency - np.eye(10)) / 15
    vectors = directions * radii[:, None]
    face_area = np.array(
        [
            np.linalg.norm(
                np.cross(
                    vectors[face[1]] - vectors[face[0]],
                    vectors[face[2]] - vectors[face[0]],
                )
            )
            / 2
            for face in faces
        ]
    )
    species_sign = 2 * species - 1
    face_species = np.array([np.prod(species_sign[face]) for face in faces])
    geometry = np.array(
        [(face_area[i] + face_area[j]) / 2 for i, j in pairs]
    )
    chemistry = np.array(
        [(face_species[i] + face_species[j]) / 2 for i, j in pairs]
    )
    geometry = projection @ (geometry - np.mean(geometry))
    chemistry = projection @ (chemistry - np.mean(chemistry))

    def cubic(weights):
        coefficients = harmonic_coefficients(axes, weights)
        return normalized_w6(coefficients), float(np.linalg.norm(weights))

    geometric, geometric_norm = cubic(geometry)
    chemical, chemical_norm = cubic(chemistry)
    return geometric, geometric_norm, chemical, chemical_norm


def minimum_image(delta, box):
    return delta - box * np.rint(delta / box)


def load_frames(path):
    table = pd.read_csv(path)
    frames = {}
    for step, frame in table.groupby("step", sort=True):
        frames[int(step)] = {
            "position": frame[["x", "y", "z"]].to_numpy(),
            "type": frame["type"].to_numpy(),
            "box": float(frame["box"].iloc[0]),
            "temperature": float(frame["temperature"].iloc[0]),
            "potential": float(frame["potential_per_atom"].iloc[0]),
        }
    return frames


def environment_rows(frames, lag_frames):
    steps = sorted(frames)
    rows = []
    for frame_index, step in enumerate(steps[:-lag_frames]):
        current = frames[step]
        future = frames[steps[frame_index + lag_frames]]
        box = current["box"]
        wrapped = np.mod(current["position"], box)
        tree = cKDTree(wrapped, boxsize=box)
        _, neighbors = tree.query(wrapped, k=13)
        for atom, neighbor_ids in enumerate(neighbors[:, 1:]):
            vectors = minimum_image(
                wrapped[neighbor_ids] - wrapped[atom], box
            )
            radii = np.linalg.norm(vectors, axis=1)
            directions = vectors / radii[:, None]
            ordinary_q6 = q6(directions)
            ordinary_w6 = normalized_w6(harmonic_coefficients(directions))
            channel = clebsch_channel(
                directions, radii, current["type"][neighbor_ids]
            )
            if channel is None or not np.all(np.isfinite(channel)):
                continue

            displacement = future["position"] - current["position"]
            cage_relative = (
                displacement[atom] - np.mean(displacement[neighbor_ids], axis=0)
            )
            rows.append(
                {
                    "step": step,
                    "atom": atom,
                    "type": current["type"][atom],
                    "q6": ordinary_q6,
                    "w6": ordinary_w6,
                    "radial_std": np.std(radii),
                    "c4_geometry": channel[0],
                    "c4_geometry_norm": channel[1],
                    "c4_chemistry": channel[2],
                    "c4_chemistry_norm": channel[3],
                    "log_mobility": np.log10(np.dot(cage_relative, cage_relative) + 1e-10),
                }
            )
    return pd.DataFrame(rows)


def evaluate(table):
    baseline = ["type", "q6", "w6", "radial_std"]
    extended = baseline + [
        "c4_geometry",
        "c4_geometry_norm",
        "c4_chemistry",
        "c4_chemistry_norm",
    ]
    split = np.quantile(table["step"], 0.7)
    train = table["step"] <= split
    test = table["step"] > split
    y_train = table.loc[train, "log_mobility"]
    y_test = table.loc[test, "log_mobility"]
    results = {"rows": int(len(table)), "train_rows": int(train.sum()), "test_rows": int(test.sum())}

    for name, features in (("baseline", baseline), ("extended", extended)):
        model = HistGradientBoostingRegressor(
            max_iter=180,
            max_leaf_nodes=15,
            learning_rate=0.06,
            l2_regularization=1,
            random_state=20260725,
        )
        model.fit(table.loc[train, features], y_train)
        prediction = model.predict(table.loc[test, features])
        results[name] = {
            "mae": float(mean_absolute_error(y_test, prediction)),
            "r2": float(r2_score(y_test, prediction)),
        }

    threshold = np.quantile(y_train, 0.8)
    y_train_class = y_train > threshold
    y_test_class = y_test > threshold
    for name, features in (("baseline", baseline), ("extended", extended)):
        model = make_pipeline(
            StandardScaler(),
            LogisticRegression(C=0.5, max_iter=2000, random_state=20260725),
        )
        model.fit(table.loc[train, features], y_train_class)
        score = model.predict_proba(table.loc[test, features])[:, 1]
        results[name]["mobility_auc"] = float(roc_auc_score(y_test_class, score))

    icosahedral = table[(table["q6"] > 0.45) & (table["w6"] < -0.08)].copy()
    results["icosahedral_rows"] = int(len(icosahedral))
    for feature in ("c4_geometry", "c4_chemistry"):
        positive = icosahedral[icosahedral[feature] > 0]["log_mobility"]
        negative = icosahedral[icosahedral[feature] < 0]["log_mobility"]
        results[f"{feature}_sign"] = {
            "positive_n": int(len(positive)),
            "negative_n": int(len(negative)),
            "positive_mean": float(positive.mean()) if len(positive) else None,
            "negative_mean": float(negative.mean()) if len(negative) else None,
        }
    return results


def ideal_check():
    phi = (1 + np.sqrt(5)) / 2
    vertices = []
    for zero in range(3):
        for a in (-1, 1):
            for b in (-1, 1):
                vertices.append(
                    (
                        (0, a, b * phi),
                        (a, b * phi, 0),
                        (a * phi, 0, b),
                    )[zero]
                )
    directions = np.array(vertices, dtype=float)
    directions /= np.linalg.norm(directions, axis=1)[:, None]
    value = normalized_w6(harmonic_coefficients(directions))
    if not np.isclose(value, -0.169753894, atol=2e-6):
        raise RuntimeError(f"W6 normalization check failed: {value}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("trajectory", type=Path)
    parser.add_argument("--lag-frames", type=int, default=10)
    parser.add_argument("--rows-output", type=Path)
    parser.add_argument("--results-output", type=Path)
    arguments = parser.parse_args()
    ideal_check()
    frames = load_frames(arguments.trajectory)
    rows = environment_rows(frames, arguments.lag_frames)
    results = evaluate(rows)
    if arguments.rows_output:
        rows.to_csv(arguments.rows_output, index=False)
    if arguments.results_output:
        arguments.results_output.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
