from collections import defaultdict
from fractions import Fraction


Q = Fraction
ZERO = (Q(0), Q(0))
ONE = (Q(1), Q(0))
PHI = (Q(1, 2), Q(1, 2))
INV_PHI = (Q(-1, 2), Q(1, 2))


def q5(value):
    return Q(value), Q(0)


def q5_add(x, y):
    return x[0] + y[0], x[1] + y[1]


def q5_neg(x):
    return -x[0], -x[1]


def q5_mul(x, y):
    return x[0] * y[0] + 5 * x[1] * y[1], x[0] * y[1] + x[1] * y[0]


def q5_scale(x, value):
    return x[0] * value, x[1] * value


def q5_sign(x):
    value = float(x[0]) + float(x[1]) * 5**0.5
    return 1 if value > 0 else -1


def poly_add(left, right, scale=ONE):
    result = defaultdict(lambda: ZERO)
    result.update(left)
    for exponent, coefficient in right.items():
        result[exponent] = q5_add(result[exponent], q5_mul(scale, coefficient))
    return {key: value for key, value in result.items() if value != ZERO}


def poly_mul(left, right):
    result = defaultdict(lambda: ZERO)
    for a, u in left.items():
        for b, v in right.items():
            exponent = tuple(a[i] + b[i] for i in range(3))
            result[exponent] = q5_add(result[exponent], q5_mul(u, v))
    return {key: value for key, value in result.items() if value != ZERO}


def poly_power(poly, exponent):
    result = {(0, 0, 0): ONE}
    for _ in range(exponent):
        result = poly_mul(result, poly)
    return result


def double_factorial(value):
    result = 1
    for factor in range(value, 0, -2):
        result *= factor
    return result


def sphere_average(poly):
    result = ZERO
    for (a, b, c), coefficient in poly.items():
        if a % 2 or b % 2 or c % 2:
            continue
        moment = Q(
            double_factorial(a - 1)
            * double_factorial(b - 1)
            * double_factorial(c - 1),
            double_factorial(a + b + c + 1),
        )
        result = q5_add(result, q5_scale(coefficient, moment))
    return result


def dodecahedral_axes():
    points = []
    for a in (-1, 1):
        for b in (-1, 1):
            for c in (-1, 1):
                points.append((q5(a), q5(b), q5(c)))
    for zero_coordinate in range(3):
        for a in (-1, 1):
            for b in (-1, 1):
                short = q5_scale(INV_PHI, Q(a))
                long = q5_scale(PHI, Q(b))
                points.append(
                    (
                        (ZERO, short, long),
                        (short, long, ZERO),
                        (long, ZERO, short),
                    )[zero_coordinate]
                )

    representatives = []
    for point in points:
        first = next(value for value in point if value != ZERO)
        representative = (
            point if q5_sign(first) > 0 else tuple(q5_neg(value) for value in point)
        )
        if representative not in representatives:
            representatives.append(representative)
    assert len(representatives) == 10
    return representatives


R2 = {(2, 0, 0): ONE, (0, 2, 0): ONE, (0, 0, 2): ONE}


def zonal_harmonic(axis):
    dot = {
        (1, 0, 0): axis[0],
        (0, 1, 0): axis[1],
        (0, 0, 1): axis[2],
    }
    terms = (
        (poly_power(dot, 6), Q(231, 432)),
        (poly_mul(poly_power(dot, 4), R2), Q(-35, 16)),
        (poly_mul(poly_power(dot, 2), poly_power(R2, 2)), Q(35, 16)),
        (poly_power(R2, 3), Q(-5, 16)),
    )
    result = {}
    for poly, coefficient in terms:
        result = poly_add(result, poly, q5(coefficient))
    return result


def dot(left, right):
    result = ZERO
    for a, b in zip(left, right):
        result = q5_add(result, q5_mul(a, b))
    return result


def p6(value):
    value2 = q5_mul(value, value)
    value4 = q5_mul(value2, value2)
    value6 = q5_mul(value4, value2)
    result = q5_scale(value6, Q(231))
    result = q5_add(result, q5_scale(value4, Q(-315)))
    result = q5_add(result, q5_scale(value2, Q(105)))
    result = q5_add(result, q5(-5))
    return q5_scale(result, Q(1, 16))


def gram_and_petersen(axes):
    gram = []
    for left in axes:
        row = []
        for right in axes:
            row.append(p6(q5_scale(dot(left, right), Q(1, 3))))
        gram.append(row)

    allowed = {q5(1), q5(Q(47, 243)), q5(Q(-65, 243))}
    assert {value for row in gram for value in row} == allowed
    adjacency = [
        [1 if gram[i][j] == q5(Q(-65, 243)) else 0 for j in range(10)]
        for i in range(10)
    ]
    assert all(sum(row) == 3 for row in adjacency)
    return gram, adjacency


def mat_vec(matrix, vector):
    return [sum(row[j] * vector[j] for j in range(len(vector))) for row in matrix]


def verify_four_vector(adjacency):
    vector = [3] * 4 + [-2] * 6
    assert mat_vec(adjacency, vector) == [-2 * value for value in vector]
    return vector


def main():
    axes = dodecahedral_axes()
    _, adjacency = gram_and_petersen(axes)
    weights = verify_four_vector(adjacency)

    field = {}
    for weight, axis in zip(weights, axes):
        field = poly_add(field, zonal_harmonic(axis), q5(weight))

    norm = sphere_average(poly_power(field, 2))
    cubic = sphere_average(poly_power(field, 3))
    sigma3 = Q(20)
    scalar = q5_scale(cubic, Q(1, 20))

    assert norm == q5(Q(2800, 351))
    assert cubic == q5(Q(-15680000, 1247103))
    assert scalar == q5(Q(-784000, 1247103))

    print("K=(196 I + 47 J - 112 A)/243")
    print("K eigenvalues: 110/81 on 1, 140/81 on 4, 28/81 on 5")
    print(f"sphere_average(F^2)={norm[0]}")
    print(f"sphere_average(F^3)={cubic[0]}")
    print(f"sigma3(4,-1,-1,-1,-1)={sigma3}")
    print(f"W6|V4={scalar[0]}*sigma3")


if __name__ == "__main__":
    main()
